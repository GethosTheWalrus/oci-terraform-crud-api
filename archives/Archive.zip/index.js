"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
// import serverless from 'serverless-http';
const server_service_1 = require("./services/server.service");
const environment_1 = require("./environment/environment");
const serverless = require('serverless-http');
server_service_1.ServerService.initServer();
console.log('DEPLOYMENT STARATEGY:', environment_1.DEPLOYMENT);
if (environment_1.DEPLOYMENT == 'serverless') {
    console.log('USERING SERVERLESS-HTTP');
    module.exports.handler = serverless(server_service_1.ServerService.app, {});
}
else {
    server_service_1.ServerService.startServer();
}
