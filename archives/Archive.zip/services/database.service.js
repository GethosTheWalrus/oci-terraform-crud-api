"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUsersFromDatabase = void 0;
const environment_1 = require("../environment/environment");
const dynamoDB_util_1 = require("../utils/dynamoDB.util");
const oracleDB_util_1 = require("../utils/oracleDB.util");
function getUsersFromDatabase(userId) {
    return __awaiter(this, void 0, void 0, function* () {
        let users;
        switch (environment_1.INFRA) {
            case 'oci': {
                users = yield (0, oracleDB_util_1.getUsersFromOracleDatabase)(userId);
                break;
            }
            case 'aws': {
                users = yield (0, dynamoDB_util_1.getUsersFromDynamoDB)(userId);
                break;
            }
            default: {
                users = [];
            }
        }
        return users;
    });
}
exports.getUsersFromDatabase = getUsersFromDatabase;
