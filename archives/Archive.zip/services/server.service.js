"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServerService = void 0;
const cors_1 = __importDefault(require("cors"));
const express_1 = __importDefault(require("express"));
const body_parser_1 = __importDefault(require("body-parser"));
const mainRouter_1 = require("../routes/mainRouter");
const environment_1 = require("../environment/environment");
const oracleDB_util_1 = require("../utils/oracleDB.util");
class ServerService {
    /*
     * Initialize the express http server
    */
    static initServer() {
        switch (environment_1.INFRA) {
            case 'oci': {
                console.log('running on OCI');
                _a.seedOracleDatabase();
                break;
            }
            case 'aws': {
                console.log('running on AWS');
                break;
            }
        }
        // connect the additional modules and the routers to the http server
        _a.app.use(body_parser_1.default.json());
        _a.app.use((0, cors_1.default)());
        _a.app.use(mainRouter_1.mainRouter);
    }
    static startServer() {
        _a.server.listen(3000);
    }
    static seedOracleDatabase() {
        return __awaiter(this, void 0, void 0, function* () {
            let connection;
            try {
                // Use the connection string copied from the cloud console
                // and stored in connstring.txt file from Step 2 of this tutorial
                connection = yield (0, oracleDB_util_1.openConnection)();
                // Create a table
                yield connection.execute(`begin execute immediate 'drop table users'; exception when others then if sqlcode <> -942 then raise; end if; end;`);
                yield connection.execute(`create table users (id number, username varchar2(100))`);
                // Insert some rows
                const sql = `INSERT INTO users VALUES (:1, :2)`;
                const binds = [[1, "user1"], [2, "user2"], [3, "user3"], [4, "user4"], [5, "user5"], [6, "user6"], [7, "user7"]];
                yield connection.executeMany(sql, binds);
                connection.commit();
            }
            catch (err) {
                console.error(err);
            }
            finally {
                if (connection) {
                    yield (0, oracleDB_util_1.closeConnection)(connection);
                }
            }
        });
    }
}
exports.ServerService = ServerService;
_a = ServerService;
ServerService.app = (0, express_1.default)();
ServerService.server = require('http').createServer(_a.app);
ServerService.healthy = false;
