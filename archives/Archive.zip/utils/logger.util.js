"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logMessageSomewhere = void 0;
// implement logging to something like Splunk here
function logMessageSomewhere(message) {
    console.log(message);
}
exports.logMessageSomewhere = logMessageSomewhere;
