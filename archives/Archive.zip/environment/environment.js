"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEPLOYMENT = exports.INFRA = exports.ROOT_URL = exports.CONNECTION_STRING = void 0;
// process.env
exports.CONNECTION_STRING = process.env.ORACLEDB_CONNECTION_STRING || '';
exports.ROOT_URL = process.env.SITEURL || 'localhost:3000';
exports.INFRA = process.env.INFRA || 'oci';
exports.DEPLOYMENT = process.env.DEPLOYMENT || 'normal';
